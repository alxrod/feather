package database

type Message struct {
	Id     string    `bson:"-"`
	RoomId string    `bson:"room_id"`
	Type   string    `bson:"type"`
	Body   []BodyNub `bson:"body"`
}

type BodyNub struct {
	Detail string `bson:"detail"`
}
