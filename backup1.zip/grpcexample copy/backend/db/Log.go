package database

type LogEntry struct {
	Payload string `bson: "payload"`
}
