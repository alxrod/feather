import AuthService from "../services/auth.service";

export const REGISTER_SUCCESS = "auth/REGISTER_SUCCESS"
export const REGISTER_FAIL = "auth/REGISTER_FAIL"
export const LOGIN_SUCCESS = "auth/LOGIN_SUCCESS"
export const LOGIN_FAIL = "auth/LOGIN_FAIL"
export const LOGOUT = "auth/LOGOUT"
export const SET_MESSAGE = "auth/SET_MESSAGE"
export const CLEAR_MESSAGE = "auth/CLEAR_MESSAGE"

const user = JSON.parse(localStorage.getItem("user"));
const initialState = user
? { isLoggedIn: true, user }
: { isLoggedIn: false, user: null };



export default (state = initialState, action) => {
    switch (action.type) {
        case SET_MESSAGE:
            return {
                ...state,
                message: action.payload
            }
        
        case CLEAR_MESSAGE:
            return {
                ...state,
                message: ""
            }

        case REGISTER_SUCCESS:
            return {
                ...state,
                isLoggedIn: false,
            };
        
        case REGISTER_FAIL:
            return {
                ...state,
                isLoggedIn: false,
            };
        
        case LOGIN_SUCCESS:
            return {
                ...state,
                isLoggedIn: true,
                user: action.payload.user,
        };
        
        case LOGIN_FAIL:
            return {
                ...state,
                isLoggedIn: false,
                user: null,
            };
        
        case LOGOUT:
            return {
                ...state,
                isLoggedIn: false,
                user: null,
            };
        
        default:
            return state
    }
}

export const register = (username, email, password) => {
    return dispatch => {
        return AuthService.register(username, email, password).then(
            (response) => {
                dispatch({
                    type: REGISTER_SUCCESS,
                });
                dispatch({
                    type: SET_MESSAGE,
                    payload: "You have successfuly registered!"
                });
                return Promise.resolve();
            },
            (error) => {
                const message = 
                    (error.response &&
                     error.response.data &&
                     error.response.data.message) ||
                    error.message ||
                    error.toString();
                dispatch({
                    type: REGISTER_FAIL,
                });
                dispatch({
                    type: SET_MESSAGE,
                    payload: message,
                });
                return Promise.reject();
            }
        );
    }
};

export const login = (username, password) => {
    return dispatch => {
        return AuthService.login(username, password).then(
            (data) => {
                dispatch({
                    type: LOGIN_SUCCESS,
                    payload: {user: data},
                });
                return Promise.resolve();
            },
            (error) => {
                const message = 
                    (error.response &&
                     error.response.data &&
                     error.response.data.message) ||
                    error.messsage ||
                    error.toString();
                dispatch({
                    type: LOGIN_FAIL,
                });
                dispatch({
                    type: SET_MESSAGE,
                    payload: message,
                });
                return Promise.reject();
            }
        );
    }
};

export const logout = () => {
    return dispatch => {
        AuthService.logout();
        dispatch({
            type: LOGOUT,
        });
    }
}

export const clearMessage = () => {
    return dispatch => {
        dispatch({
            type: CLEAR_MESSAGE,
        });
    }
}