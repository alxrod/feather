import { AuthClient, SocialClient, PaymentClient } from "../proto/communication/user_grpc_web_pb";
import { 
    UserLoginRequest,
    UserRegisterRequest,
    UserLogoutRequest,

    InstagramCreateRequest,
    InstagramVerifyRequest,
    TiktokCreateRequest,
    TiktokVerifyRequest,

    PaymentSetupRequest,

 } from "../proto/communication/user_pb";

var authClient = new AuthClient("https://localhost:8080");
var socialClient = new SocialClient("https://localhost:8080");
var paymentClient = new PaymentClient("https://localhost:8080");

class UserService {
    // Auth Requests
    login(username, password) {
        var loginRequest = new UserLoginRequest();   
        loginRequest.setUsername(username);
        loginRequest.setPassword(password);

        return new Promise( (resolve, reject) => { 
            authClient.login(loginRequest, null, function(error, response) {
                var resp = response.toObject();
                if (error) {
                    reject(error)
                }
                if (resp.token) {
                    var data = {
                        username: resp.username,
                        accessToken: resp.token,
                    }
                    localStorage.setItem("user", JSON.stringify(data));
                    resolve(data)
                }
                if (resp.success === false && resp.error !== "") {
                    reject(new Error(resp.error))
                }
               reject(new Error("Catch all invalid request"))
            });
        });
    }

    register(username, email, password) {

        var registerRequest = new UserRegisterRequest();   
        registerRequest.setUsername(username);
        registerRequest.setEmail(email);
        registerRequest.setPassword(password);

        return new Promise (function (resolve, reject) {
            authClient.register(registerRequest, null, function(err, response) {
                var resp = response.toObject();
                if (err) {
                    reject(err)
                }
                if (resp.token) {
                    const data = {
                        username: resp.username,
                        accessToken: resp.token
                    }
                    localStorage.setItem("user", JSON.stringify(data));
                    resolve()
                }
                if (resp.success === false && resp.error !== "") {
                    reject(resp.error)
                }
                reject(new Error("Catch all invalid request"))
            });
        });
    }

    logout() {
        var logoutRequest = new UserLogoutRequest();   
        
        var user = JSON.parse(localStorage.getItem("user"));
        if (user === null) {
            return Error("You are not currently logged in")
        }
        logoutRequest.setUsername(user.username);
        logoutRequest.setToken(user.accessToken);

        authClient.logout(logoutRequest, null, function(err, response) {
            var resp = response.toObject();
            if (err) {
                return err
            }
            if (resp.success) {
                localStorage.removeItem("user");
            } else {
                return Error(resp.error)
            }
        });
        return Error("Request failed")
        
    }

    // Social Setup Requests
    add_instagram(account, user_id) {
        var loginRequest = new InstagramCreateRequest;   
        loginRequest.setAccount(account);
        loginRequest.setUserId(user_id);
        // TODO connect these to Paul's authenticator
        loginRequest.setVerified(true);
        loginRequest.setFollowers(100,000);

        return new Promise( (resolve, reject) => { 
            authClient.login(loginRequest, null, function(error, response) {
                var resp = response.toObject();
                if (error) {
                    reject(error)
                }
                if (resp.token) {
                    var data = {
                        username: resp.username,
                        accessToken: resp.token,
                    }
                    localStorage.setItem("user", JSON.stringify(data));
                    resolve(data)
                }
                if (resp.success === false && resp.error !== "") {
                    reject(new Error(resp.error))
                }
               reject(new Error("Catch all invalid request"))
            });
        });
    }
}

export default new UserService();