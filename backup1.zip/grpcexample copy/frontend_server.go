package main

import (
	"embed"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"time"

	"github.com/TwiN/go-color"
	"github.com/improbable-eng/grpc-web/go/grpcweb"
)

var routes []string = []string{
	"/",
	"/example",
	"/login",
	"/register",
	"/profile",
	"/logout",
	"/settle",
}

type FrontServer struct {
	router *http.ServeMux
	webapp http.Handler
}

func NewFrontServer(react_fs embed.FS) (*FrontServer, error) {
	fsys := fs.FS(react_fs)
	contentStatic, _ := fs.Sub(fsys, "ui/pingpongapp/build")
	srv := &FrontServer{
		router: http.NewServeMux(),
		webapp: http.FileServer(http.FS(contentStatic)),
	}
	return srv, nil
}

func (srv *FrontServer) InitRoutes(multiplex *grpcMultiplexer) error {
	var err error
	for _, path := range routes {
		err = srv.AddRoute(path, multiplex.Handler(srv.webapp))
		if err != nil {
			return err
		}
	}
	return nil
}

func (srv *FrontServer) AddRoute(path string, handler http.Handler) error {
	srv.router.Handle(path, http.StripPrefix(path, handler))
	return nil
}

func (srv *FrontServer) Serve(addr string) {
	s := &http.Server{
		Handler:      srv.router,
		Addr:         addr,
		WriteTimeout: 15 * time.Second,
		ReadTimeout:  15 * time.Second,
	}
	log.Println(color.Ize(color.Green, "Serving Frontend on 127.0.0.1:8080"))
	log.Fatal(s.ListenAndServeTLS("cert/server.crt", "cert/server.key"))
}

type grpcMultiplexer struct {
	*grpcweb.WrappedGrpcServer
}

func (m *grpcMultiplexer) Handler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if m.IsGrpcWebRequest(r) {
			m.ServeHTTP(w, r)
			return
		}
		fmt.Printf(color.Ize(color.Purple, fmt.Sprintf("Frontend Request for : %s\n", r.URL)))
		next.ServeHTTP(w, r)
	})
}
